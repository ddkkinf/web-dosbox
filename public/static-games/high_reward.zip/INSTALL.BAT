@echo off
cls
echo .
echo .
echo  +-----------------------------+
echo         High   Reward          
echo  +-----------------------------+
echo .
echo   ..........  Install  .........
echo .
echo .
if /%1==/ goto USAGE
if /%2==/ goto USAGE
goto SEIJYOU
:USAGE
echo install   Disk-Drive-Name:   Hard-Disk-Drive-Name:
echo .
echo .
echo .
goto END
:SEIJYOU
%2:
cd \
md rewa
copy %1\instsub.bat  %2\rewa > nul
cd %2\rewa
instsub %1 %2
:END
