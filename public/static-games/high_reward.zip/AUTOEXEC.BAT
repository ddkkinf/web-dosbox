@ECHO off
SET BLASTER=A220 I5 D1 T4
SET PATH=C:\;C:\WINDOWS;C:\WINDOWS\COMMAND;C:\UTIL;c:\util\gw32;C:\VIRUS;C:\TRIGEM\CDROM;C:\TRIGEM\HV
lh c:\util\cloc
lh c:\util\mouse.exe

