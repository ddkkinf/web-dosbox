@echo off
SET SOUND=COMP
SET BLASTER=A220 I7 D1 H5 P330 T6
SET MIDI=SYNTH:1 MAP:E
sig
cls
MEMCHK
if errorlevel 1 goto quitprog
hrdrv  -f:hrfnt.kor -tj >nul
OP
MA
MAIN
if errorlevel 1 goto quitprog
END
:quitprog
hrdrv -r >nul
sig -R
