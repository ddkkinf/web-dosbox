@echo off
echo .
echo .
echo COPY____    Disk  No.1  -----  Hard  %2
copy %1\*.*  %2\rewa > nul
echo .
:no2
echo .
echo Insert  Disk  No.2  To  %1
pause
if not exist %1\ed0.gs goto no2
echo COPY____    Disk  No.2  -----  Hard  %2
copy %1\*.*  %2\rewa > nul
echo .
:no3
echo .
echo Insert  Disk  No.3  To  %1
pause
if not exist %1\face.mrg goto no3
echo COPY____    Disk  No.3  -----  Hard  %2
copy %1\*.*  %2\rewa > nul
echo .
:no4
echo .
echo Insert  Disk  No.4  To  %1
pause
if not exist %1\semtmp.ovc goto no4
echo COPY____    Disk  No.4  -----  Hard  %2
copy %1\*.*  %2\rewa > nul
:no5
echo .
echo Insert  Disk  No.5  To  %1
pause
if not exist %1\ed0.rgb goto no5
echo COPY____    Disk  No.5  -----  Hard  %2
copy %1\*.*  %2\rewa > nul

setsound
