@echo off
main.exe
