@echo off
cls
prince megahit
