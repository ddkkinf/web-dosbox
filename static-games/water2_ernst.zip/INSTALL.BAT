cd \horizons
install
